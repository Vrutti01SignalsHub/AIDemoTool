
function get_st_btns() {
    var all_btn = $("button.stButton");
    console.log(all_btn);
}

$(document).ready(function () {
    console.log('Hello from Hydralit Experimental!');
});