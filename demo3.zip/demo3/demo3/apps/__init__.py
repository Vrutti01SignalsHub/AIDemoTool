from apps.home_app import HomeApp
from apps.data_cleaning import datacleanApp
# from apps.walsh_app import WalshApp
# from apps.walsh_app_secure import WalshAppSecure
from apps.login_app import LoginApp
# from apps.solar_mach import SolarMach
# from apps.spacy_nlp import SpacyNLP
# from apps.uber_app import UberNYC
# from apps.cheat_app import CheatApp
from apps.myloading_app import MyLoadingApp
from apps.signup import SignUpApp
# from apps.cookie_cutter import CookieCutterApp
from apps.load_app import LoaderTestApp
